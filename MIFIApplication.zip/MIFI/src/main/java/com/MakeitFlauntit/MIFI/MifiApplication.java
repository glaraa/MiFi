package com.MakeitFlauntit.MIFI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MifiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MifiApplication.class, args);
	}

}
