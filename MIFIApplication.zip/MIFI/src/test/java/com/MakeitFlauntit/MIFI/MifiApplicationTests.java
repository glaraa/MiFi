package com.MakeitFlauntit.MIFI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MifiApplicationTests {

	@Test
	void contextLoads() {
	}

}
